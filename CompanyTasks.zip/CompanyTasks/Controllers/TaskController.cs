﻿using CompanyTasks.Data;
using CompanyTasks.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace CompanyTasks.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class TaskController : ApiController
    {
        private readonly TaskDbContext _taskDbContext;

        public TaskController()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["TasksDB"];

            SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString.ConnectionString);

            DbProviderFactory dbProviderFactory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            DbConnection dbConnection = dbProviderFactory.CreateConnection();
            dbConnection.ConnectionString = sqlConnectionStringBuilder.ConnectionString;

            _taskDbContext = new TaskDbContext(dbConnection);
        }

        public TaskController(TaskDbContext taskDbContext)


        {
            if (taskDbContext == null)
                throw new ArgumentNullException("taskDbContext is null");

            _taskDbContext = taskDbContext;
        }

        private bool _disposed = false;

        protected override void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _taskDbContext.Dispose();
                }
                _disposed = true;
            }
            base.Dispose(disposing);
        }



        //get task list
        [HttpGet]
        [Route("api/GetTasks")]
        public IHttpActionResult GetTasks()
        {
            var TasksRecrods = _taskDbContext.GetTaskList();

            if (TasksRecrods == null)
                return NotFound();
            else
                return Ok(TasksRecrods);
        }

        //get users
        [HttpGet]
        [Route("api/GetUsers")]
        public IHttpActionResult GetUsers()
        {
            var usersRecrods = _taskDbContext.GetUsers().ToList();

            if (usersRecrods == null)
                return NotFound();
            else
                return Ok(usersRecrods);
        }

        //post task
        [HttpPost]
        [Route("api/PostTask")]
        public IHttpActionResult PostBook([FromBody]TaskRecord taskRecord)
        {
            try
            {
                ///get tasks
                var taskListRecord = _taskDbContext.GetTaskList2().Where(x => x.UserID == taskRecord.UserID && x.Done == false);

                if(taskListRecord.Count() == 10)
                    return BadRequest("user have already 10 open tasks");

                if (taskListRecord.Any(x => x.TaskName == taskRecord.TaskName))
                    return BadRequest("the user have already this task");

                    _taskDbContext.TaskList.Add(taskRecord);
                _taskDbContext.SaveChanges();

                return Ok(_taskDbContext.TaskList);
            }
            catch (Exception err)
            {
                return BadRequest(err.Message);
            }

        }

    }
}
