﻿using CompanyTasks.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CompanyTasks.Data
{
    public class TaskDbContext : DbContext
    {
        public TaskDbContext(DbConnection dbConnection) : base(dbConnection, true) { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //TasksList
            //map table
            modelBuilder.Entity<TaskRecord>().ToTable("TaskList");
            //map key
            modelBuilder.Entity<TaskRecord>().HasKey(k => k.ID);
            //Identity
            modelBuilder.Entity<TaskRecord>().Property(p => p.ID).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);


            //Users
            //map table
            modelBuilder.Entity<UserRecord>().ToTable("Users");
            //map key
            modelBuilder.Entity<UserRecord>().HasKey(k => k.ID);
            //Identity
            modelBuilder.Entity<UserRecord>().Property(p => p.ID).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
        }


        public DbSet<TaskRecord> TaskList { get; set; }
        public DbSet<UserRecord> Users { get; set; }


        //qry
        //get users
        public IQueryable<UserRecord> GetUsers()
        {
            return Users;
        }

        public List<TaskView> GetTaskList()
        {

            var result = (from _taskList in TaskList
                          join _users in Users
                          on _taskList.UserID equals _users.ID
                          select new TaskView { 
                             ID =  _taskList.ID,
                              TaskName = _taskList.TaskName,
                              UserName = _users.UserName,
                              Done = _taskList.Done
                          }).ToList();
            return result;
        }

        public IQueryable<TaskRecord> GetTaskList2()
        {
            return TaskList;
        }


    }
}