import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service'

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {

  taskListRecords: any;
  userPerTasks: any;


  constructor(public apiService: ApiService) { }

  ngOnInit(): void {

    //load
    this.load();

  }

  async load(){
    let _taskListRecord: any;
    _taskListRecord = await this.apiService.GetTasks();
    this.taskListRecords = _taskListRecord;

    //count
    this.userPerTasks = this.taskListRecords.reduce( (a, x) => (a[x.UserName] = (a[x.UserName] || 0)+1, a), {} );
    //this.userPerTasks = this.taskListRecords.filter().map(x => x.Done === false).reduce((acc, score) => acc + score, 0);



    debugger;
  }



}
