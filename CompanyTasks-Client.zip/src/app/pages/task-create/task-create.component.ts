import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { TaskRecord } from 'src/app/models/task-record';
import { UserRecord } from 'src/app/models/user-record';

@Component({
  selector: 'app-task-create',
  templateUrl: './task-create.component.html',
  styleUrls: ['./task-create.component.css']
})
export class TaskCreateComponent implements OnInit {

  taskRecord: TaskRecord = {TaskName : '', UserName: '', Done: false, UserID: 0};
  userRecords: UserRecord;

  constructor(public apiService: ApiService, public router: Router) { }

  ngOnInit(): void {
    
    //load users
    this.loadUsers();
  }

  async loadUsers(){
    let _userRecords: any;
    _userRecords = await this.apiService.GetUsers();
    this.userRecords = _userRecords;
  }

    //create
    async create(){
      debugger;
      const success = await this.apiService.CreateTask(this.taskRecord);
      if (success) {
        return;
      }else{
        //err note 
      }
    }
    
    
    createTask(){
      this.create();
      this.router.navigateByUrl('/task-list');
    }

}
