import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TaskListComponent } from '../app/pages/task-list/task-list.component';
import { TaskCreateComponent } from '../app/pages/task-create/task-create.component';

const routes: Routes = [
  {path:  "", pathMatch:  "full",redirectTo:  "home"},
  {path: "home", component: TaskListComponent},
  {path: "task-list", component: TaskListComponent},  
  {path: "task-create", component: TaskCreateComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
