import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { TaskRecord } from '../models/task-record';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  //headers
  private headers: object = {
    "Accept": "*/*",
    "Content-Type": "application/json"
  };

  //get tsak
  GetTasks(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(`${environment.api}/GetTasks`,
      {
        headers: {
          ...this.headers
        }
      })
      .toPromise()
      .then((data: any) => {
        return resolve(data);
      })
      .catch(error => {
        return reject(error);
      });
    });
  }

  //get users
  GetUsers(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.get(`${environment.api}/GetUsers`,
      {
        headers: {
          ...this.headers
        }
      })
      .toPromise()
      .then((data: any) => {
        return resolve(data);
      })
      .catch(error => {
        return reject(error);
      });
    });
  }

  //create book
  CreateTask(taskRecord: TaskRecord): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(`${environment.api}/PostTask`,
      taskRecord,
      {
        headers: {
          ...this.headers
        },
      })
      .toPromise()
      .then((data: any) => {
        return resolve(data);
      })
      .catch(error => {
        return reject(error);
      });
    });
  }

}
