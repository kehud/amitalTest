export interface UserRecord {
    ID: number;
    UserName: string;
}
