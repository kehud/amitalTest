export interface TaskRecord {
    TaskName: string;
    UserName: string;
    UserID: number;
    Done: boolean;
}
